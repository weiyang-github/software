破解文件夹里的【app.asar】复制到软件安装路径下的【resources】文件夹内替换原文件。
邮箱：crack@example.com
DZTX2H-6MCQZT-QL4GCT-5EBWFX
G7LPKN-HP4NLD-FA3BGF-6JDQ5R
3MH4Y8-YJWT37-G5JL9Y-UHNQDJ
85ZPHY-ELQ9FQ-94J3VP-D92YLU(测试通过)
VEZ7NV-USYN3G-8TL2N3-DADUG4(测试通过)

破解参考
https://blog.csdn.net/CSDN__Walker/article/details/123601776